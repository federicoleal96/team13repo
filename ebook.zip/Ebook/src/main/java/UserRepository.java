import com.example.ebook.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Repository interface for user-related database operations.
 * We're using Optional to handle the case where no user is found with the given email.
 */
@Repository
public interface UserRepository extends JpaRepository<User, String> {

    /**
     * Finds a user by email (case insensitive).
     * @param email the email to search for
     * @return an Optional containing the user if found, or an empty Optional if not found
     */
    Optional<User> findByEmailIgnoreCase(String email);
}