import com.example.ebook.model.User;
import com.example.ebook.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.regex.Pattern;

/**
 * Service class for user-related operations.
 */
@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    /**
     * Creates a new user and saves it to the database.
     * Checks if the email already exists in the database (case insensitive) and validates the password using a regular expression.
     * @param user the user to create
     * @return the created user
     * @throws Exception if the email already exists or the password is invalid
     */
    public User createUser(User user) throws Exception {
        // Check if email already exists
        if (userRepository.findByEmailIgnoreCase(user.getEmail())!= null) {
            throw new Exception("Email already exists");
        }

        // Validate password
        if (!isValidPassword(user.getPassword())) {
            throw new Exception("Password must contain at least one uppercase letter, one lowercase letter, and one number");
        }

        return userRepository.save(user);
    }

    /**
     * Checks if a password is valid by ensuring it contains at least one uppercase letter, one lowercase letter, and one number.
     * @param password the password to validate
     * @return true if the password is valid, false otherwise
     */
    private boolean isValidPassword(String password) {
        String regex = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).*$";
        return Pattern.matches(regex, password);
    }
}